#!/usr/bin/env python3

from main import start_ui

start_ui()