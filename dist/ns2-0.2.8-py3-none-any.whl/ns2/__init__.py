from .service import start_ui

__version__ = "0.2.8"

def service():
    start_ui()