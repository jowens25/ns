#!/usr/bin/env python3


def run():
    from main import start_ui

    start_ui()
